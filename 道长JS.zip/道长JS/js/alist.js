[
   {
      "name": "🙋丫仙女",
      "server": "http://alist.xiaoya.pro/",
      "startPage": "/",
      "showAll": false,
      "search": true,
      "headers": {
         "Authorization": ""
      },
      "params": {
         "/abc": {
            "password": "123"
         },
         "/abc/abc": {
            "password": "123"
         }
      }
   },
   {
      "name": "🐋一只鱼",
      "server": "https://alist.youte.ml"
   },
   {
      "name": "🌊七米蓝",
      "server": "https://al.chirmyram.com"
   },
   {
      "name": "🐉神族九帝",
      "server": "https://alist.shenzjd.com"
   },
   {
      "name": "☃️姬路白雪",
      "server": "https://pan.jlbx.xyz"
   },
   {
      "name": "✨星梦",
      "server": "https://pan.bashroot.top"
   },
   {
      "name": "💢repl",
      "server": "https://ali.liucn.repl.co"
   },
   {
      "name": "💦讯维云盘",
      "server": "https://pan.xwbeta.com"
   }
]
